
#fais des graphs boxplot  #Y=axe Y ; Ylab="titre de l'axe Y ; Z la dataframe L'axe X c'est toujours le génotype
#' Plettre
#'
#' @param Y data_Y
#' @param Z data
#' @param X data_X
#' @param Xlab Xlab
#' @param Ylab Ylab
#' @param Tukey test_used
#' @import ggplot2
#' @import dplyr
#' @return plot and stats
#' @export
#'
#' @examples
#'
#' #pour les lettres
tri.to.squ<-function(x)
{
  rn <- row.names(x)
  cn <- colnames(x)
  an <- unique(c(cn,rn))
  myval <-  x[!is.na(x)]
  mymat <-  matrix(1,nrow=length(an),ncol=length(an),dimnames=list(an,an))
  for(ext in 1:length(cn))
  {
    for(int in 1:length(rn))
    {
      if(is.na(x[row.names(x)==rn[int],colnames(x)==cn[ext]])) next
      mymat[row.names(mymat)==rn[int],colnames(mymat)==cn[ext]]<-x[row.names(x)==rn[int],colnames(x)==cn[ext]]
      mymat[row.names(mymat)==cn[ext],colnames(mymat)==rn[int]]<-x[row.names(x)==rn[int],colnames(x)==cn[ext]]
    }

  }
  return(mymat)
}
Plettre_modif=function(Y,Z,X, Xlab="x", Ylab="y",Tukey=T){

    #for verif normalité des résidus et homogénéité des variances
  mod2<-aov(Y~X)

  #calcule lettre significativiter ----
  #normalement ne fonctionne que si le teste de kruscal walis est significatif

  Kteste=kruskal.test(Y ~X, data=Z) # YES !!!!

  #Faire anova ? non car pas plus de 10 par gébitype d'après Marion


  # réalisation des comparaisons deux à deux des moyennes par des tests de Wilcoxon (pool.sd=F), avec ajustement des pvalues par la méthode de Holm
  # et récupération de la matrice triangulaire des p-values

  if(Tukey==F){
    pp <- pairwise.t.test(Y, X,p.adjust.method ="holm",paired = F,pool.sd=F) #voire ici pourquoi methode holm et pourquoi on a besoins d'ajuster les pvalue (pour diminuer les faux positif autrement dit le risque derreur) https://delladata.fr/comparaisons-multiples-et-ajustement-des-pvalues-avec-le-logiciel-r/  #si vraiment je veux avoir les resultats de student je dois a la place de holm ecrire none et utiliser pool.sd (car je ne pas fait de test sur l'egalité de variance). (Simply put, if you are making multiple comparisons, you are increasing the chances of finding spurious results. A correction adjusts for this.)
    # réalisation des comparaisons deux à deux des moyennes par des tests de Wilcoxon (ou man_witney),(pas besoins de verif l’hypothèse d’homoscedasticité ou d’égalité des variances) avec ajustement des pvalues par la méthode de Holm. Foncionne bien sur les petits echantillon. https://jonathanlenoir.files.wordpress.com/2013/12/tests-de-comparaison-de-moyennes-non-param.pdf / https://stat.ethz.ch/R-manual/R-devel/library/stats/html/p.adjust.html

    #voire ici pourquoi j'ai choisis pool.sd=F
    #https://stats.stackexchange.com/questions/337749/in-r-how-can-the-p-value-during-pairwise-t-tests-without-adjustment-be-differen


    ############### attention 'j'ai changer tout les graphs du coup !!! pool.sd avant était true
    pp

    # transformation de la matrice triangulaire de p-values en une matrice rectangulaire
    mymat <-tri.to.squ(pp$p.value)
    mymat

    # création des lettres correspondant à chaque moyenne
    myletters <- multcompLetters(mymat,compare="<=",threshold=0.05,Letters=letters)
    myletters
    # conserver les lettre dans un data.frame
    myletters_df <- data.frame(group=names(myletters$Letters),letter = myletters$Letters)
  }else{
    tuktuk<-TukeyHSD(mod2, ordered=FALSE, conf.level=0.95, na.rm=T)

    multcompLetters4(mod2, tuktuk)

    myletters=multcompLetters4(mod2, TukeyHSD(mod2,ordered=FALSE, conf.level=0.95, na.rm=T))
    myletters_df=as.data.frame(rownames(myletters$X$LetterMatrix))
    for (i in 1:length(myletters$X$Letters)){
      #print(myletters$X$Letters[[i]])
      myletters_df$letter[i]=myletters$X$Letters[[i]]
    }

    colnames(myletters_df)=c("groupe","letter")
    rownames(myletters_df)=myletters_df$groupe
  }


  #Afficher les résultats des différences à l’aide de lettres
  # plot
  #faire un merge pour que ça fonctionne
  Z$group=NA

  for(i in 1:length(Y)){
    for(j in 1:length(myletters_df$group)){
      if(X[i]==myletters_df$group[j]){
        Z$group[i]=as.character(myletters_df$letter[j])
      }else{}
    }

  }

  #graph
  p=ggplot(Z, aes(x=X, y=Y, colour=X, fill=X))+
    geom_boxplot(outlier.alpha = 0, alpha=0.25)+
    geom_jitter(width=0.25)+
    #stat_summary(fun.y=mean, colour="black", geom="point",
    #            shape=18, size=3) +
    theme_bw()+
    theme(legend.position="none")+
    theme(axis.text.x = element_text(angle=45, hjust=1, vjust=1))+geom_text(data = Z, aes(label = group, y = 1.05*max(Y[!is.na(Y)])))+xlab(Xlab)+ylab(Ylab)+labs(caption=paste0("kruskal test=",format.pval(Kteste$p.value,digits = 2)))+scale_fill_manual(values=manu_palett)+scale_color_manual(values=manu_palett)
  return(list(p,paste0(cat("###Normality of residues / Shapiro-Wilk normality test","\n"),
                       cat(shapiro.test(mod2$resid)$p.value,"\n","###Homogeneity of variance / Levene's Test for Homogeneity of Variance (center = median) conf=95%","\n",leveneTest(mod2)$`Pr(>F)`[[1]]))))
}
